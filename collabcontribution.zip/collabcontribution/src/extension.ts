// // The module 'vscode' contains the VS Code extensibility API
// // Import the module and reference it with the alias vscode in your code below
// import * as vscode from 'vscode';

// // This method is called when your extension is activated
// // Your extension is activated the very first time the command is executed
// export function activate(context: vscode.ExtensionContext) {

// 	// Use the console to output diagnostic information (console.log) and errors (console.error)
// 	// This line of code will only be executed once when your extension is activated
// 	console.log('Congratulations, your extension "collabcontribution" is now active!');

// 	// The command has been defined in the package.json file
// 	// Now provide the implementation of the command with registerCommand
// 	// The commandId parameter must match the command field in package.json
// 	let disposable = vscode.commands.registerCommand('collabcontribution.helloWorld', () => {
// 		// The code you place here will be executed every time your command is executed
// 		// Display a message box to the user
// 		vscode.window.showInformationMessage('Hello World from collabContribution!');
// 	});

// 	context.subscriptions.push(disposable);
// }

// // This method is called when your extension is deactivated
// export function deactivate() {}

import * as vscode from 'vscode';
// import { spawnSync } from 'child_process';
// import { parse } from 'path';
// import * as ast from 'ast-types';
// import { visit } from 'ast-types';

export function activate(context: vscode.ExtensionContext) {
  // Register the command to calculate user contribution score
  const userContributionScoreCommand = vscode.commands.registerCommand(
    'extension.calculateUserContributionScore',
    () => {
      // Get the active text editor
      const editor = vscode.window.activeTextEditor;
      if (!editor) {
        vscode.window.showErrorMessage('No active text editor found');
        return;
      }

      // Get the document text
      const document = editor.document;
      const text = document.getText();

      // Calculate the user contribution score
      const userScores = calculateUserContributionScore(text);

      // Display the user scores
      vscode.window.showInformationMessage(JSON.stringify(userScores));
    }
  );

  context.subscriptions.push(userContributionScoreCommand);
}

function calculateUserContributionScore(text: string): Record<string, number> {
    // // Extract user contributions from the text
	// const userContributions: Record<string, { lines_count: number; text_input: number }> = {};
	// const lines = text.split('\n');
	// const userRegex = /#user (\d+)/;
	// lines.forEach((line, index) => {
	//   const match = line.match(userRegex);
	//   if (match) {
	// 	const userId = match[1];
	// 	if (!userContributions[userId]) {
	// 	  userContributions[userId] = { lines_count: 0, text_input: 0 };
	// 	}
	// 	userContributions[userId].lines_count += 1;
	// 	userContributions[userId].text_input += line.length;
	//   }
	// });
  
	// // Calculate code quality metrics
	// const pylintOutput = spawnSync('pylint', ['-f', 'json', '--disable=all', '--enable=W,E'], { input: text }).stdout.toString();
	// const pylintMessages = JSON.parse(pylintOutput);
	// const codeQualityIssues: Record<string, number> = {};
	// pylintMessages.forEach((message: any) => {
	//   const lineNumber = message.line;
	//   const line = lines[lineNumber - 1];
	//   const match = line.match(userRegex);
	//   if (match) {
	// 	const userId = match[1];
	// 	if (!codeQualityIssues[userId]) {
	// 	  codeQualityIssues[userId] = 0;
	// 	}
	// 	codeQualityIssues[userId] += 1;
	//   }
	// });
  
	// // Calculate code relevance scores
	// const codeRelevanceScores: Record<string, number> = {};
	// const tree = ast.parse(text, { sourceType: 'module' });
	// visit(tree, {
	//   visitFunctionDeclaration: function (path) {
	// 	const lineNumber = path.node.loc.start.line;
	// 	const line = lines[lineNumber - 1];
	// 	const match = line.match(userRegex);
	// 	if (match) {
	// 	  const userId = match[1];
	// 	  if (!codeRelevanceScores[userId]) {
	// 		codeRelevanceScores[userId] = 0;
	// 	  }
	// 	  codeRelevanceScores[userId] += 1;
	// 	}
	// 	this.traverse(path);
	//   },
	//   visitVariableDeclaration: function (path) {
	// 	const lineNumber = path.node.loc.start.line;
	// 	const line = lines[lineNumber - 1];
	// 	const match = line.match(userRegex);
	// 	if (match) {
	// 	  const userId = match[1];
	// 	  if (!codeRelevanceScores[userId]) {
	// 		codeRelevanceScores[userId] = 0;
	// 	  }
	// 	  codeRelevanceScores[userId] += 1;
	// 	}
	// 	this.traverse(path);
	//   },
	// });
	// // Normalize score components and calculate final scores
	// const userScores: Record<string, number> = {};
	// Object.keys(userContributions).forEach((userId) => {
	//   const linesCount = userContributions[userId].lines_count;
	//   const textInput = userContributions[userId].text_input;
	//   const codeQuality = codeQualityIssues[userId] ? 1 - codeQualityIssues[userId] / linesCount : 1;
	//   const codeRelevance = codeRelevanceScores[userId] ? codeRelevanceScores[userId] / linesCount : 0;
	  
	//   // Assign weights to the components
	// const linesCountWeight = 0.2;
	// const textInputWeight = 0.2;
	// const codeQualityWeight = 0.2;
	// const codeRelevanceWeight = 0.2;
	// const errorReductionWeight = 0.2; // Assuming no errors for simplicity, set this to 1

	// // Calculate the final score
	// const score =
	// linesCountWeight * linesCount +
	// textInputWeight * textInput +
	// codeQualityWeight * codeQuality +
	// codeRelevanceWeight * codeRelevance +
	// errorReductionWeight;

	// // Multiply the final score by 100 to convert it to a score out of 100
	// userScores[userId] = score * 100;
	// });

	// return userScores;
	
	// Implement the user contribution score calculation algorithm here.
  // For now, just return an empty object to represent user scores.
  return {user1: 80, user2: 20};
}

export function deactivate() {}
