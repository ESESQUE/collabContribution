// // The module 'vscode' contains the VS Code extensibility API
// // Import the module and reference it with the alias vscode in your code below
// import * as vscode from 'vscode';

// // This method is called when your extension is activated
// // Your extension is activated the very first time the command is executed
// export function activate(context: vscode.ExtensionContext) {

// 	// Use the console to output diagnostic information (console.log) and errors (console.error)
// 	// This line of code will only be executed once when your extension is activated
// 	console.log('Congratulations, your extension "collabcontribution" is now active!');

// 	// The command has been defined in the package.json file
// 	// Now provide the implementation of the command with registerCommand
// 	// The commandId parameter must match the command field in package.json
// 	let disposable = vscode.commands.registerCommand('collabcontribution.helloWorld', () => {
// 		// The code you place here will be executed every time your command is executed
// 		// Display a message box to the user
// 		vscode.window.showInformationMessage('Hello World from collabContribution!');
// 	});

// 	context.subscriptions.push(disposable);
// }

// // This method is called when your extension is deactivated
// export function deactivate() {}


import * as vscode from 'vscode';
import { spawnSync } from 'child_process';
import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import { promisify } from 'util';
import { copyFile } from 'fs/promises';
import * as child_process from 'child_process';
import { resourceLimits } from 'worker_threads';

// let userName: string | undefined; // variable to store user's name
export class SharedState {
    public userName: string;

    constructor(userName: string) {
        this.userName = userName;
    }
}

export function activate(context: vscode.ExtensionContext) {
	// Initialize the shared state with an empty userName
	let sharedState = new SharedState('');

	let disposable1 = vscode.commands.registerCommand('extension.calculateUserContributionScore', async () => {
		// Ask the instructor to enter the filepath for the test cases
		const testCasesFilePath = await vscode.window.showInputBox({ prompt: 'Enter the filepath for the test cases:' });

		if (!testCasesFilePath) {
			vscode.window.showErrorMessage('No test cases filepath provided.');
			return;
		}

		// Ask the user to enter the directory path for the temp code files
		const dirPath = await vscode.window.showInputBox({ prompt: 'Enter the directory path for the temp code files:' });

		// Check if the path was provided
		if (dirPath) {
			// Run the function and store the result
			// const userScores = calculateUserContributionScore(dirPath, testCasesFilePath);
			// Calculate the final score
			// const finalScores =  calculateFinalScore(userScores);

			const userScoreOverTime = calculateUserScoreOverTime(dirPath, testCasesFilePath);
			const finalScores =  calculateFinalScore(userScoreOverTime);
			
			// Display the result
			vscode.window.showInformationMessage(JSON.stringify(finalScores));
		} else {
			vscode.window.showErrorMessage('Directory path not provided.');
		}
	});

	let disposable2 = vscode.commands.registerCommand('extension.identifyUser', async () => {
        // // Ask the user to enter their name
        // const inputName = await vscode.window.showInputBox({ prompt: 'Enter your name:' });

        // // Save the entered name in the userName variable, make it a global variable
		// userName = inputName;

        // // You can display a message to confirm
        // vscode.window.showInformationMessage(`Hello, ${userName}!`);

		// Prompt the user for their username
		vscode.window.showInputBox({ prompt: 'Enter your username:' }).then((userName) => {
			if (userName) {
				// Update the shared state with the provided userName
				sharedState.userName = userName;
			}
		});
    });

	let disposable3 = vscode.commands.registerCommand('extension.countLinesOfCode', async () => {
		// Ask the user to enter the directory path for the temp code files
		const dirPath = await vscode.window.showInputBox({ prompt: 'Enter the directory path for the temp code files:' });
	
		// Check if the path was provided
		if (dirPath) {
			// Run the function and store the result
			const lineCounts = countLinesOfCode(dirPath);
			const totalLinesCounts = calculateTotalLines(lineCounts);
			
			// Display the result
			vscode.window.showInformationMessage(JSON.stringify(lineCounts));
		} else {
			vscode.window.showErrorMessage('Directory path not provided.');
		}
	});

	let disposable4 = vscode.commands.registerCommand('extension.runTestCases', async () => {
		// Ask the instructor to enter the filepath for the test cases
		const testCasesFilePath = await vscode.window.showInputBox({ prompt: 'Enter the filepath for the test cases:' });

		if (!testCasesFilePath) {
			vscode.window.showErrorMessage('No test cases filepath provided.');
			return;
		}

		// Ask the user to enter the directory path for the temp code files
		// const dirPath = await vscode.window.showInputBox({ prompt: 'Enter the directory path for the temp code files:' });
		const editor = vscode.window.activeTextEditor;
		if (editor){
			const dirPath2 = path.dirname(editor.document.uri.fsPath);
			const dirPath = path.join(dirPath2, '.temp_code');
	

			// Check if the path was provided
			if (dirPath) {
				// Run the function and store the result
				const testCaseScore = runTestCases(dirPath, testCasesFilePath);
				const testCaseScoreProcessed = processTestCases(testCaseScore);
				const userScoreOverTime = calculateUserScoreOverTime(dirPath, testCasesFilePath);
				
				// Display the result
				vscode.window.showInformationMessage(JSON.stringify(testCaseScore));
			} else {
				vscode.window.showErrorMessage('Directory path not provided.');
		}
	}
	});

	let disposable5 = vscode.commands.registerCommand('extension.userError', async () => {
		// Ask the user to enter the directory path for the temp code files
		const dirPath = await vscode.window.showInputBox({ prompt: 'Enter the directory path for the temp code files:' });
	
		// Check if the path was provided
		if (dirPath) {
			// Run the function and store the result
			const userError = calculateUserErrorCont(dirPath);
			
			// Display the result
			vscode.window.showInformationMessage(JSON.stringify(userError));
		} else {
			vscode.window.showErrorMessage('Directory path not provided.');
		}
	});



	let disposable7 = vscode.commands.registerCommand('extension.copyFileHighest', async () => {
		// Ask the user to enter the directory path
		// const dirPath = await vscode.window.showInputBox({ prompt: 'Enter the directory path for the current file:' });

		// get the directory of the active text editor

		const editor = vscode.window.activeTextEditor;
		if (!editor) {
			vscode.window.showErrorMessage('No active editor found.');
			return;
		}
		const dirPath = editor.document.uri.fsPath;

		
		const dirPath2 = path.dirname(editor.document.uri.fsPath);
		const destinationPath = path.join(dirPath2, '.temp_code');

		// print destination path in message
		// vscode.window.showErrorMessage(destinationPath);

		if (!fs.existsSync(destinationPath)){
			fs.mkdirSync(destinationPath);
		}
		
		// const destinationPath = '/Users/saeedalqubaisi/.vscode/extensions/collabcontribution/temp_code'
		// const destinationPath = '/Users/saeedalqubaisi/Desktop/exercise_files/.temp_code'
		// Check if the path was provided
		if (destinationPath) {
			// Run the function and store the result
			copyFileHighest(dirPath,destinationPath,sharedState.userName);

			// Display the result
			vscode.window.showInformationMessage("milestone saved");
		} else {
			vscode.window.showErrorMessage('Directory path not provided.');
		}
	});


let disposable6 = vscode.commands.registerCommand('extension.generatePDF', async() => {
	// Ask the instructor to enter the filepath for the test cases
	const testCasesFilePath = await vscode.window.showInputBox({ prompt: 'Enter the filepath for the test cases:' });
	const editor = vscode.window.activeTextEditor;

	if (editor) {
		const docDir = path.dirname(editor.document.uri.fsPath);

		if (!testCasesFilePath) {
			vscode.window.showErrorMessage('No test cases filepath provided.');
			return;
		}

		const dirPath2 = path.dirname(editor.document.uri.fsPath);
		const dirPath = path.join(dirPath2, '.temp_code');

		// Check if the path was provided
		if (dirPath) {
			// Run the function and store the result
			// const userScores = calculateUserContributionScore(dirPath, testCasesFilePath);
			const userScoreOverTime = calculateUserScoreOverTime(dirPath, testCasesFilePath);
			const finalScores = calculateFinalScore(userScoreOverTime);
			const lineCounts = countLinesOfCode(dirPath);
			const totalLinesData = calculateTotalLines(lineCounts);
			const testCaseScore = runTestCases(dirPath, testCasesFilePath);
			const processedTestCases = processTestCases(testCaseScore);
			const errorsData = calculateUserErrorCont(dirPath);
			const processedErrors = errorsData.filter(row => row.introducedError !== "" || row.correctedError !== "");

			const outputFile = docDir + '/UserContributionScores.pdf';

			// convert the data to string
			const finalScoresString = JSON.stringify(finalScores);
			const userScoreOverTimeString = JSON.stringify(userScoreOverTime);
			const totalLinesDataString = JSON.stringify(totalLinesData);
			const processedErrorsString = JSON.stringify(processedErrors);
			const processedTestCasesString = JSON.stringify(processedTestCases);
			const outputFileString = JSON.stringify(outputFile);

			// Run the Python script with the data string as an argument
			let pythonScriptPath = path.join(__dirname, '../src/generatePDF.py');
			const outputDir = __dirname;

			child_process.exec(`python3 ${pythonScriptPath} '${finalScoresString}' '${userScoreOverTimeString}' '${totalLinesDataString}' '${processedErrorsString}' '${processedTestCasesString}' '${outputFile}'`, { cwd: outputDir }, (error, stdout, stderr) => {
				if (error) {
					console.error(`exec error: ${error}`);
					return;
				}
			
				console.log(`stdout: ${stdout}`);
				console.error(`stderr: ${stderr}`);
			});
			vscode.window.showInformationMessage('PDF has been generated.');
		} else {
			vscode.window.showErrorMessage('Directory path not provided.');
		}
	}
});



				   
	

	context.subscriptions.push(disposable1, disposable2, disposable3, disposable4, disposable5, disposable6, disposable7);
}

async function copyFileHighest(folderPath: string, destinationPath: string, userVariable: string): Promise<void> {
    try {
        // Read the folder contents
		//console.log (folderPath);
		//console.log (destinationPath);
		//console.log (userVariable);
        const folderContents = await promisify(fs.readdir)(destinationPath);
        console.log(folderContents);
        // Filter the files to include only those with digits after "v" in their names
        const digitFiles = folderContents.filter((filename) => {
            const match = filename.match(/v(\d+)/);
            return match !== null;
        });

        if (digitFiles.length === 0) {

            //const sourceFilePath = path.join(folderPath, highestDigitFile);
        	const newFileName = `${userVariable}_homework_v1.py`;
        	const destinationFilePath = path.join(destinationPath, newFileName);

        	// Copy the file to the destination path
        	copyFile(folderPath, destinationFilePath);
			
        }
		else{
        // Find the file with the highest digit after "v" in its name
        let highestDigitFile = digitFiles[0];
        let highestDigit = parseInt(highestDigitFile.match(/v(\d+)/)![1], 10);
		

        for (let i = 1; i < digitFiles.length; i++) {
            const currentFile = digitFiles[i];
            const currentDigit = parseInt(currentFile.match(/v(\d+)/)![1], 10);

            if (currentDigit > highestDigit) {
                highestDigit = currentDigit;
                highestDigitFile = currentFile;
            }
        }
        const newHighestDigit = highestDigit + 1;

        // Construct the source and destination paths
        //const sourceFilePath = path.join(folderPath, highestDigitFile);
        const extension = path.extname(highestDigitFile);
        const newFileName = `${userVariable}_homework_v${newHighestDigit}${extension}`;
        const destinationFilePath = path.join(destinationPath, newFileName);

        // Copy the file to the destination path
        copyFile(folderPath, destinationFilePath);

        console.log(`File '${highestDigitFile}' copied successfully and renamed to '${newFileName}'.`);
		}
    }
	
	catch (error) {
        console.error('An error occurred:', error);
    }
	
	
}

interface UserTestScore {
    userName: string;
    testScore: number;
    testsPassed: {input: string, expectedOutput: string}[];
}



function runTestCases(tempCodeFolderPath: string, testCasesFilePath: string): UserTestScore[] {
    const filesArray = loopThroughFiles(tempCodeFolderPath);
    const testScores: UserTestScore[] = [];
    let prevTestResults: boolean[] = [];

    for (let i = 0; i < filesArray.length; i++) {
        const currentFile = filesArray[i];
        const currentUserName = currentFile.userName;
        const testCases = JSON.parse(fs.readFileSync(testCasesFilePath, 'utf8'));

        let score = 0;
        let currTestResults: boolean[] = [];
        let passedTests: {input: string, expectedOutput: string}[] = [];
        for (let j = 0; j < testCases.length; j++) {
            // Create a temporary Python file with the current version
            const tempPythonFilePath = path.join(os.tmpdir(), `temp_python_code_v${i+1}.py`);
            fs.writeFileSync(tempPythonFilePath, currentFile.text);

            // Run the test case
            const pythonResult = spawnSync('python', [tempPythonFilePath], { input: testCases[j].input });
            const output = pythonResult.stdout.toString().trim();

            // Check test result
            const passed = output === testCases[j].expectedOutput.trim();
            currTestResults.push(passed);

            // If the test passed and it didn't pass in the previous version, increment the score
            if (passed && (j >= prevTestResults.length || !prevTestResults[j])) {
                score++;
                passedTests.push(testCases[j]);
            }

            // Remove the temporary Python file
            fs.unlinkSync(tempPythonFilePath);
        }
        prevTestResults = currTestResults;
        testScores.push({ userName: currentUserName, testScore: score, testsPassed: passedTests });
    }

    return testScores;
}

interface TestCase {
    input: string;
    expectedOutput: string;
}

interface TestCaseData {
    userName: string;
    testScore: number;
    testsPassed: TestCase[];
}

interface ProcessedTestCaseData {
    userName: string;
    version: number;
    input: string;
	expectedOutput: string;
}

function processTestCases(testCasesData: TestCaseData[]): ProcessedTestCaseData[] {
    let processedData: ProcessedTestCaseData[] = [];
    testCasesData.forEach((data, index) => {
        if (data.testScore > 0) {
            data.testsPassed.forEach(test => {
                processedData.push({
                    userName: data.userName,
                    version: index + 1,
                    input: test.input,
					expectedOutput: test.expectedOutput
                });
            });
        }
    });
    return processedData;
}


interface UserLines {
	userName: string;
	linesCount: number;
}

function lineofText(currentText: string): string[] {
	const currentlines = currentText.split('\n').map(line => {
	  // remove comments from end of line
	  const index = line.indexOf('#');
	  if (index !== -1) {
		line = line.substring(0, index);
	  }
	  // denote empty line or commented with comments as ''
	  if (line.trim() === '' || line.trim().startsWith('#')) {
		return '';
	  } else {
		return line;
	  }
	});
	return currentlines;
  }

function countLinesOfCode(tempCodeFolderPath: string): UserLines[] {
	// Create an ordered array with {text, userName, homeworkNumber}
	const filesArray = loopThroughFiles(tempCodeFolderPath);

	// Initialize an array to store the line counts for each user
	const lineCounts: UserLines[] = [];

	// Initialize a variable to store the lines of the previous file
	let prevLines: string[] = [];

	// Loop through the filesArray
	for (let i = 0; i < filesArray.length; i++) {
		const currentFile = filesArray[i];
		const currentText = currentFile.text;
		const currentUserName = currentFile.userName;

		
		// Split the text into lines and filter out the empty lines
		//const lines = currentText.split('\n').filter(line => line.trim() !== '');
		const lines = lineofText(currentText);

		//filter to find only lines of code
		const currentlinesUpdated = lines.filter(line => line !== '');

		// Determine the lines that were added in this version by comparing with the previous version
		const addedLines = currentlinesUpdated.filter(line => !prevLines.includes(line));

		// Add a new entry for the user with the number of lines added in the current version
		lineCounts.push({ userName: currentUserName, linesCount: addedLines.length });

		// Update the previous lines to be the lines of the current version
		prevLines = currentlinesUpdated;
	}

	return lineCounts;
}

type DataType = { userName: string; linesCount: number; };

function calculateTotalLines(data: DataType[]): { userName: string; totalLines: number; }[] {
    let totalLinesMap = data.reduce((acc: { [key: string]: number; }, val: DataType) => {
        if (!acc[val.userName]) {
            acc[val.userName] = val.linesCount;
        } else {
            acc[val.userName] += val.linesCount;
        }
        return acc;
    }, {});

    let totalLinesArray = [];
    for (let user in totalLinesMap) {
        totalLinesArray.push({userName: user, totalLines: totalLinesMap[user]});
    }

    return totalLinesArray;
}



interface FileObject {
	text: string;
	userName: string;
	homeworkNumber: number;
}

function loopThroughFiles(tempCodeFolderPath: string): FileObject[] {
	//create an ordered object with {text, userName, homeworkNumber} 
	const filesArray: FileObject[] = [];
	fs.readdirSync(tempCodeFolderPath).forEach(file => {
		const regex = /^(.*)_homework_v(\d+)\.py$/;
		const match = regex.exec(file);
		if (match) {
			const userName = match[1];
			const homeworkNumber = Number(match[2]);

			const filePath = path.join(tempCodeFolderPath, file);
			const text = fs.readFileSync(filePath, { encoding: 'utf-8' });

			filesArray.push({ text, userName, homeworkNumber });
		}
	});

	filesArray.sort((a, b) => {
		return a.homeworkNumber - b.homeworkNumber;
	});
	return filesArray;
}

interface userErrors {
	userName: string;
	errorNum: number;
	errorType: string;
	errorText: string;
	lineNum: number;
}

function recordUserErrors(tempCodeFolderPath: string): userErrors[] {
	//Types of Errors
	const pythonErrors = [
		'AssertionError',
		'AttributeError',
		'EOFError',
		'FloatingPointError',
		'GeneratorExit',
		'ImportError',
		'ModuleNotFoundError',
		'IndexError',
		'KeyError',
		'KeyboardInterrupt',
		'MemoryError',
		'NameError',
		'NotImplementedError',
		'OSError',
		'OverflowError',
		'RecursionError',
		'ReferenceError',
		'RuntimeError',
		'StopIteration',
		'StopAsyncIteration',
		'SyntaxError',
		'IndentationError',
		'TabError',
		'SystemError',
		'SystemExit',
		'TypeError',
		'UnboundLocalError',
		'UnicodeError',
		'UnicodeEncodeError',
		'UnicodeDecodeError',
		'UnicodeTranslateError',
		'ValueError',
		'ZeroDivisionError',
		'EnvironmentError',
		'IOError',
		'WindowsError',
		'BlockingIOError',
		'ChildProcessError',
		'ConnectionError',
		'BrokenPipeError',
		'ConnectionAbortedError',
		'ConnectionRefusedError',
		'ConnectionResetError',
		'FileExistsError',
		'FileNotFoundError',
		'InterruptedError',
		'IsADirectoryError',
		'NotADirectoryError',
		'PermissionError',
		'ProcessLookupError',
		'TimeoutError'
	];
	//create an ordered object with {text, userName, homeworkNumber} 
	const filesArray = loopThroughFiles(tempCodeFolderPath);
	const userErrors: userErrors[] = [];

	//loop through filesArray homeworkNumber
	for (let i = 0; i < filesArray.length; i++) {
		const currentFile = filesArray[i];
		const currentText = currentFile.text;
		const currentUserName = currentFile.userName;

		//Find the line of error
		const lines = currentText.split('\n').map(line => {
			// remove comments from end of line
			const index = line.indexOf('#');
			if (index !== -1) {
				line = line.substring(0, index);
			}
			// denote line with comments as ''
			if (line.trim() === '') {
				return '';
			} else {
				return line;
			}
		});

		const result = spawnSync('python', ['-c', currentText], {input: "10 20", encoding: 'utf-8' });
		if (result.status !== 0) {
			const errorOutput = result.stderr.trim();
			//finding line of error
			const regex = /File "<string>", line (\d+)/g;
			const match = regex.exec(errorOutput);

			if (match) {
				const lineNumber = Number(match[1]);
				// errorNum
				const currnetNum = 1;
				//get the exact error text
				const errorLine = lines[lineNumber - 1].trim();
				//check error type 
				let currentType: string | null = null;
				for (const error of pythonErrors) {
					if (errorOutput.includes(error)) {
						currentType = error;
						break; // break out of loop if error is found
					} else {
						currentType = 'UndefinedError';;
					}
				}

				//update the userErrors object
				if (currentType) {
					userErrors.push({
						userName: currentUserName,
						errorNum: currnetNum,
						errorType: currentType,
						errorText: errorLine,
						lineNum: lineNumber
					});
				}
			}
		} else {
			userErrors.push({
				userName: currentUserName,
				errorNum: 0,
				errorType: 'No Errors',
				errorText: 'No lines of Error',
				lineNum: 0
			});
		}
	}
	return userErrors;
}

interface userErrorCont {
	userName: string;
	errorScore: number;
	introducedError: string;
	correctedError: string;
}

function calculateUserErrorCont(tempCodeFolderPath: string): userErrorCont[] {

	const userErrorCont: userErrorCont[] = [];
	const userErrors = recordUserErrors(tempCodeFolderPath);
	const filesArray = loopThroughFiles(tempCodeFolderPath);
	type ErrorTypeScores = {
		[key: string]: number;
	  };
	  
	const errorTypeScores: ErrorTypeScores = {
		// Critical Errors (-5)
		SystemExit: -5,
		KeyboardInterrupt: -5,
		UndefinedError: -5,
	  
		// Major Errors (-4)
		AssertionError: -4,
		ImportError: -4,
		ModuleNotFoundError: -4,
		NameError: -4,
		SyntaxError: -4,
		IndentationError: -4,
		TabError: -4,
		TypeError: -4,
		ValueError: -4,
		ZeroDivisionError: -4,
		RecursionError: -4,
		KeyError: -4,
		IndexError: -4,
	  
		// Moderate Errors (-2)
		AttributeError: -2,
		EOFError: -2,
		FloatingPointError: -2,
		GeneratorExit: -2,
		NotImplementedError: -2,
		OSError: -2,
		OverflowError: -2,
		ReferenceError: -2,
		RuntimeError: -2,
		StopAsyncIteration: -2,
		StopIteration: -2,
		SystemError: -2,
		UnboundLocalError: -2,
		UnicodeError: -2,
		UnicodeEncodeError: -2,
		UnicodeDecodeError: -2,
		UnicodeTranslateError: -2,
	  
		// File System Errors (-3)
		EnvironmentError: -3,
		IOError: -3,
		WindowsError: -3,
		BlockingIOError: -3,
		ChildProcessError: -3,
		ConnectionError: -3,
		BrokenPipeError: -3,
		ConnectionAbortedError: -3,
		ConnectionRefusedError: -3,
		ConnectionResetError: -3,
		FileExistsError: -3,
		FileNotFoundError: -3,
		InterruptedError: -3,
		IsADirectoryError: -3,
		NotADirectoryError: -3,
		PermissionError: -3,
		ProcessLookupError: -3,
		TimeoutError: -3,
	  };



	  type ErrorTypeSolved = {
		[key: string]: number;
	  };
	  const errorTypeSolved: ErrorTypeSolved = {
        // Critical Errors (9)
        SystemExit: 9,
        KeyboardInterrupt: 9,
        UndefinedError: 9,
      
        // Major Errors (8)
        AssertionError: 8,
        ImportError: 8,
        ModuleNotFoundError: 8,
        NameError: 8,
        SyntaxError: 8,
        IndentationError: 8,
        TabError: 8,
        TypeError: 8,
        ValueError: 8,
        ZeroDivisionError: 8,
        RecursionError: 8,
        KeyError: 8,
        IndexError: 8,
      
        // Moderate Errors (6)
        AttributeError: 6,
        EOFError: 6,
        FloatingPointError: 6,
        GeneratorExit: 6,
        NotImplementedError: 6,
        OSError: 6,
        OverflowError: 6,
        ReferenceError: 6,
        RuntimeError: 6,
        StopAsyncIteration: 6,
        StopIteration: 6,
        SystemError: 6,
        UnboundLocalError: 6,
        UnicodeError: 6,
        UnicodeEncodeError: 6,
        UnicodeDecodeError: 6,
        UnicodeTranslateError: 6,
      
        // File System Errors (7)
        EnvironmentError: 7,
        IOError: 7,
        WindowsError: 7,
        BlockingIOError: 7,
        ChildProcessError: 7,
        ConnectionError: 7,
        BrokenPipeError: 7,
        ConnectionAbortedError: 7,
        ConnectionRefusedError: 7,
        ConnectionResetError: 7,
        FileExistsError: 7,
        FileNotFoundError: 7,
        InterruptedError: 7,
        IsADirectoryError: 7,
        NotADirectoryError: 7,
        PermissionError: 7,
        ProcessLookupError: 7,
        TimeoutError: 7,
      };


	for (let i = 0; i < userErrors.length; i++) {
		//find the current version num of lines of code
		const currentFile = filesArray[i];
		const currentText = currentFile.text;

		//split the lines of code 
		// const currentlines = currentText.split('\n').map(line => {
		// 	// remove comments from end of line
		// 	const index = line.indexOf('#');
		// 	if (index !== -1) {
		// 		line = line.substring(0, index);
		// 	}
		// 	// denote empty line or commented with comments as ''
		// 	if (line.trim() === '' || line.trim().startsWith('#')) {
		// 		return '';
		// 	} else {
		// 		return line;
		// 	}
		// });
		const currentlines = lineofText(currentText)
		const currentlinesUpdated = currentlines.filter(line => line !== '');


		//find the current version errors and error types
		const currentFileError = userErrors[i];
		const currentUserName = currentFileError.userName;
		const currenterrorNum = currentFileError.errorNum;
		const currenterrorType = currentFileError.errorType;
		const currenterrorText = currentFileError.errorText;

		//if this is the first file
		if (i === 0) {
			//if no error found and there is code 
			if (currenterrorNum === 0 && currentlinesUpdated.length !== 0) {
				userErrorCont.push({
					userName: currentUserName,
					errorScore: 5,
					introducedError: '',
					correctedError: ''
				});
				//if errors found
			} else if (currenterrorNum === 1) {
				const currentErrorScore = errorTypeScores[currenterrorType];
				userErrorCont.push({
					userName: currentUserName,
					errorScore: currentErrorScore,
					introducedError: currenterrorType,
					correctedError: ''
				});
				//if there is no code *commented*
			} else {
				userErrorCont.push({
					userName: currentUserName,
					errorScore: 0,
					introducedError: '',
					correctedError: ''
				});
			}
		}
		//if this is not the first file - comparing with the previous file
		else {
			//get the previous text 
			const previousFile = filesArray[i - 1];
			const previousText = previousFile.text;

			//split the lines of code 
			// const previouslines = previousText.split('\n').map(line => {
			// 	// remove comments from end of line
			// 	const index = line.indexOf('#');
			// 	if (index !== -1) {
			// 		line = line.substring(0, index);
			// 	}
			// 	// denote line with comments as ''
			// 	if (line.trim() === '' || line.trim().startsWith('#')) {
			// 		return '';
			// 	} else {
			// 		return line;
			// 	}
			// });
			const previouslines = lineofText(previousText);
			//remove irrelavent lines
			const previouslinesUpdated = previouslines.filter(line => line !== '');

			const previousFileError = userErrors[i - 1];
			const previousUserName = previousFileError.userName;
			const previouserrorNum = previousFileError.errorNum;
			const previouserrorType = previousFileError.errorType;
			const previouserrorText = previousFileError.errorText;

			//if no error found
			if (currenterrorNum === 0 && currentlinesUpdated.length !== 0) {
				//check if previous also no error and he introduced code
				if (previouserrorNum === 0 && previouslinesUpdated !== currentlinesUpdated) {
					//user did not introduce error
					userErrorCont.push({
						userName: currentUserName,
						errorScore: 5,
						introducedError: '',
						correctedError: ''
					});
					//check if user resolve error
				} else if (previouserrorNum === 1) {
					//user could have deleted or resolved the error
					const currentErrorScore = errorTypeSolved[previouserrorType];
					userErrorCont.push({
						userName: currentUserName,
						errorScore: currentErrorScore,
						introducedError: '',
						correctedError: previouserrorType
					});
					// he didnt contirbute
				} else if (previouserrorNum === 0 && previouslinesUpdated === currentlinesUpdated) {
					//user could have deleted or resolved the error
					userErrorCont.push({
						userName: currentUserName,
						errorScore: 0,
						introducedError: '',
						correctedError: ''
					});
				}
			//if errors found
			} else if (currenterrorNum === 1) {
				//check if it the same as the previous error
				if (previouserrorType === currenterrorType && previouserrorText === currenterrorText) {
					userErrorCont.push({
						userName: currentUserName,
						errorScore: -1,
						introducedError: currenterrorType,
						correctedError: ''
					});
				//or it is a new error introduced
				} else {
					const currentErrorScore = errorTypeScores[currenterrorType];
					userErrorCont.push({
						userName: currentUserName,
						errorScore: currentErrorScore,
						introducedError: currenterrorType,
						correctedError: ''
					});
				}
			}
			//if everything is commented by the user
			else {
				userErrorCont.push({
					userName: currentUserName,
					errorScore: 0,
					introducedError: '',
					correctedError: ''
				});
			}
		}
	}
	return userErrorCont;
}

interface UserScoreOverTime{
	userName: string;
	userScore: number;
	version: number;
}


interface LineCountDataType {
    userName: string;
    linesCount: number;
}

interface TestScoreDataType {
    userName: string;
    testScore: number;
    testsPassed: any[];
}

interface ErrorScoreDataType {
    userName: string;
    errorScore: number;
    introducedError: string;
    correctedError: string;
}

function normalizeData<T extends { [key: string]: any }>(data: T[], field: keyof T): T[] {
    let sumExp = data.reduce((sum, item) => sum + Math.pow(Math.E, item[field] || 0), 0);
    return data.map(item => ({...item, [field]: Math.pow(Math.E, item[field] || 0) / sumExp}));
}

function calculateUserScoreOverTime(
	tempCodeFolderPath: string,
	testCasesFilePath: string
): UserScoreOverTime[] {
	// Calculate the number of lines of code written by each user
	const linesCountData = countLinesOfCode(tempCodeFolderPath);

	// Calculate the test scores for each user
	const testScoresData = runTestCases(tempCodeFolderPath, testCasesFilePath);

	// Calculate the error scores for each user
	const errorScoresData = calculateUserErrorCont(tempCodeFolderPath);

	let linesCountDataNormalized = normalizeData(linesCountData, 'linesCount');
    let testScoresDataNormalized = normalizeData(testScoresData, 'testScore');
    let errorScoresDataNormalized = normalizeData(errorScoresData, 'errorScore');


	let linesCountWeight = 0.1;
    let testScoresWeight = 0.5;
    let errorScoresWeight = 0.4;

	let userScoresOverTime: UserScoreOverTime[] = linesCountDataNormalized.map((item, i) => ({
        userName: item.userName,
        userScore: (item.linesCount || 0) * linesCountWeight + (testScoresDataNormalized[i].testScore || 0) * testScoresWeight + (errorScoresDataNormalized[i].errorScore || 0) * errorScoresWeight,
        version: i
    }));

	return userScoresOverTime;

}

interface UserScore {
    userName: string;
    userScore: number;
}


interface UserFinalScore {
    userName: string;
    finalScore: number;
}



function calculateFinalScore(userScoresOverTime: UserScoreOverTime[]): UserFinalScore[] {
    // Create a mapping of users to their cumulative scores
    let userScores: { [key: string]: number } = {};
    for (let userScore of userScoresOverTime) {
        if (userScore.userName in userScores) {
            userScores[userScore.userName] += userScore.userScore;
        } else {
            userScores[userScore.userName] = userScore.userScore;
        }
    }

    // Calculate the total score to use for normalization
    let totalScore = Object.values(userScores).reduce((a, b) => a + b, 0);

    // Create the final score objects
    let finalScores: UserFinalScore[] = [];
    for (let userName in userScores) {
        finalScores.push({ userName: userName, finalScore: userScores[userName] / totalScore });
    }

    return finalScores;
}


export function deactivate() {}
