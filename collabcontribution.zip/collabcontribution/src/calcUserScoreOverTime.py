import json
import sys

def getUserSCores(linesCountData, testScoresData, errorScoresData):
    # create a new list called linesCountData normalized, where you normalize the linesCount using softmax function
    # softmax function: e^x / sum(e^x)
    linesCountDataNormalized = []
    sumExp = sum([2.718281828459045**x["linesCount"] for x in linesCountData])
    for x in linesCountData:
        x["linesCount"] = 2.718281828459045**x["linesCount"] / sumExp
        linesCountDataNormalized.append(x)

    # normalize testScoresData using softmax function
    testScoresDataNormalized = []
    sumExp = sum([2.718281828459045**x["testScore"] for x in testScoresData])
    for x in testScoresData:
        x["testScore"] = 2.718281828459045**x["testScore"] / sumExp
        testScoresDataNormalized.append(x)

    errorScoresDataNormalized = []
    # normalize errorScoresData using softmax function
    sumExp = sum([2.718281828459045**x["errorScore"] for x in errorScoresData])
    for x in errorScoresData:
        x["errorScore"] = 2.718281828459045**x["errorScore"] / sumExp
        errorScoresDataNormalized.append(x)

    # select weight for each feature
    linesCountWeight = 0.1
    testScoresWeight = 0.5
    errorScoresWeight = 0.4

    # create a new list of dictionaries called userScores, that will end up looking like this: [{"userName":"user1","userScore":0,"version":1},{"userName":"user2","userScore":-0.30000000000000004,"version":2},{"userName":"user1","userScore":1.2999999999999998,"version":3},{"userName":"user3","userScore":-0.30000000000000004,"version":4}]
    userScores = []
    for x in range(len(linesCountDataNormalized)):
        userScores.append({"userName":linesCountDataNormalized[x]["userName"],"userScore":linesCountDataNormalized[x]["linesCount"]*linesCountWeight + testScoresDataNormalized[x]["testScore"]*testScoresWeight + errorScoresDataNormalized[x]["errorScore"]*errorScoresWeight,"version":x+1})
    
    return userScores

if __name__ == "__main__":
    linesCountData = [{"userName":"user1","linesCount":7},{"userName":"user1","linesCount":1},{"userName":"user2","linesCount":1},{"userName":"user2","linesCount":1}]
    testScoresData = [{"userName":"user1","testScore":0,"testsPassed":[]},{"userName":"user1","testScore":0,"testsPassed":[]},{"userName":"user2","testScore":0,"testsPassed":[]},{"userName":"user2","testScore":3,"testsPassed":[{"input":"3 4","expectedOutput":"7"},{"input":"10 20","expectedOutput":"30"},{"input":"-5 5","expectedOutput":"0"}]}]
    errorScoresData = [{"userName":"user1","errorScore":-2,"introducedError":"EOFError","correctedError":""},{"userName":"user1","errorScore":-1,"introducedError":"EOFError","correctedError":""},{"userName":"user2","errorScore":-1,"introducedError":"EOFError","correctedError":""},{"userName":"user2","errorScore":-1,"introducedError":"EOFError","correctedError":""}]

    # linesCountData = sys.argv[1]
    # testScoresData = sys.argv[2]
    # errorScoresData = sys.argv[3]

    # # convert them from a json string to a list of dictionaries
    # linesCountData = json.loads(linesCountData)
    # testScoresData = json.loads(testScoresData)
    # errorScoresData = json.loads(errorScoresData)
    
    print(json.dumps(getUserSCores(linesCountData, testScoresData, errorScoresData)))