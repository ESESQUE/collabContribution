import pdfkit
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import seaborn as sns
from PIL import Image
import base64
import io
import sys

def plot_bar_chart(data_string):
    data = pd.read_json(data_string)
    unique_users = data['userName'].unique()
    palette = sns.color_palette('hsv', len(unique_users))
    colors = dict(zip(unique_users, palette))

    fig, ax = plt.subplots(figsize=(10, 6))
    sns.barplot(data=data, x='version', y='userScore', hue='userName', palette=colors, ax=ax)
    ax.set_title('Bar Chart of User Scores by Version')
    plt.tight_layout()

    # Save the figure as an image in memory
    buf = io.BytesIO()
    plt.savefig(buf, format='png')
    buf.seek(0)

    # Convert the buffer contents to base64
    image_base64 = base64.b64encode(buf.read()).decode('utf-8')

    # Close the buffer
    buf.close()

    return image_base64

def data_to_html(data):
    # df = pd.DataFrame(data)
    df = pd.read_json(data)
    return df.to_html(index=False)

def generate_pdf(final_scores, user_score_over_time, total_lines_data, processed_errors, processed_test_cases, output_file):
    try:
        final_scores_html = data_to_html(final_scores)
        total_lines_data_html = data_to_html(total_lines_data)
        processed_errors_html = data_to_html(processed_errors)
        user_score_over_time_html = plot_bar_chart(user_score_over_time)
        processed_test_cases_html = data_to_html(processed_test_cases)

        html_string = f"""
        <html>
            <head>
                <style>
                table {{
                    width: 100%;
                    border-collapse: collapse;
                }}
                th, td {{
                    text-align: left;
                    padding: 8px;
                    border-bottom: 1px solid #ddd;
                }}
                th {{
                    background-color: #4CAF50;
                    color: white;
                }}
                tr:hover {{background-color:#f5f5f5;}}
                </style>
            </head>
            <body>
                <h1>Student Contributions Report</h1>
                <h2>Summary of Overall Contribution</h2>
                <p>Below is a table that displays the final contribution score for each student. The higher the score, the more the student has contributed to the project. Equal scores indicate equal contribution.</p>
                {final_scores_html}
                <p>The figure below shows the contribution of students to the project over time. The x-axis represents versions of the code in chronological order, and the colors represent the students. The higher the bar, the more that version of the code has contributed to the project.</p>
                <div id="chart">
                    <img src="data:image/png;base64,{user_score_over_time_html}" alt="User Score Over Time">
                </div>
                <h2>Total Lines of Code written</h2>
                <p>Below is a table that displays the total number of lines of code written by each student.</p>
                {total_lines_data_html}
                <h2>Test Cases Passed</h2>
                <p>The table below shows the code versions and its corresponding student that have passed the test cases supplied by the instructor. It also identifies the input and expected output of the test cases that passed.</p>
                {processed_test_cases_html}
                <h2>Errors Introduced and Corrected</h2>
                <p>In the table below, you can can see which students introduced or corrected errors, along with the score attributed to that error introduction or correction. The scores are based on the following: 
                    <ul>
                        <li>-1 for not resolving a previous error</li>
                        <li>0 for no contribution</li>
                        <li>+5 not introducing any errors</li>
                        <li>between -2 and -5 for introducing an error, based on the error's category</li>
                        <li>between +6 and +9 for correcting a previous error, based on the error's category</li>
                    </ul> 
                </p>
                {processed_errors_html}

            </body>
        </html>
        """

        pdfkit.from_string(html_string, output_file)
        print(f"PDF has been successfully created at {output_file}")
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == '__main__':
    final_scores = sys.argv[1]
    user_score_over_time = sys.argv[2]
    total_lines_data = sys.argv[3]
    processed_errors = sys.argv[4]
    processed_test_cases = sys.argv[5]
    output_file = sys.argv[6]
    generate_pdf(final_scores, user_score_over_time, total_lines_data, processed_errors, processed_test_cases, output_file)

    # final_scores =  '[{"userName":"user1","finalScore":1.0250000000000001},{"userName":"user2","finalScore":0.41250000000000003},{"userName":"user3","finalScore":0.41250000000000003}]'
    # user_score_over_time = '[{"userName":"user1","userScore":0,"version":1},{"userName":"user2","userScore":-0.30000000000000004,"version":2},{"userName":"user1","userScore":1.2999999999999998,"version":3},{"userName":"user3","userScore":-0.30000000000000004,"version":4}]'
    # total_lines_data = '[{"userName":"user1","totalLines":10},{"userName":"user2","totalLines":1},{"userName":"user3","totalLines":1}]'
    # processed_errors = '[{"userName":"user1","errorScore":-2,"introducedError":"EOFError","correctedError":""},{"userName":"user2","errorScore":-1,"introducedError":"EOFError","correctedError":""},{"userName":"user1","errorScore":-1,"introducedError":"EOFError","correctedError":""},{"userName":"user3","errorScore":-1,"introducedError":"EOFError","correctedError":""}]'
    # processed_test_cases = '[{"userName":"user1","version":3,"input":"3 4","expectedOutput":"7"},{"userName":"user1","version":3,"input":"10 20","expectedOutput":"30"},{"userName":"user1","version":3,"input":"-5 5","expectedOutput":"0"}]'
    # output_file = '/Users/saeedalqubaisi/Desktop/exercise_files/UserContributionScores.pdf'

    # generate_pdf(final_scores,user_score_over_time, total_lines_data, processed_errors, processed_test_cases, output_file)


