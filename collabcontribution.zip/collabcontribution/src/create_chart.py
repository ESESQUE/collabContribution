import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from PIL import Image
import sys


# Your data
data_string = sys.argv[1]
data_string = '[{"userName":"user1","userScore":0,"version":1},{"userName":"user2","userScore":-0.30000000000000004,"version":2},{"userName":"user1","userScore":1.2999999999999998,"version":3},{"userName":"user3","userScore":-0.30000000000000004,"version":4}]'
data = pd.read_json(data_string)

# Get a list of unique usernames
unique_users = data['userName'].unique()

# Create a color palette with the same number of colors as there are unique usernames
palette = sns.color_palette('hsv', len(unique_users))

# Create a dictionary mapping each username to a color
colors = dict(zip(unique_users, palette))

# Plotting
plt.figure(figsize=(10, 6))
sns.barplot(data=data, x='version', y='userScore', hue='userName', palette=colors)
plt.title('Bar Chart of User Scores by Version')

# save the file in /Users/saeedalqubaisi/.vscode/extensions/collabcontribution/src/test directory
plt.savefig('chart.png')

# Open the image file
img = Image.open('chart.png')

# Convert the image to RGB (this removes the alpha channel)
rgb_img = img.convert('RGB')

# Save the new image
rgb_img.save('chart.png')

